import boto3
from botocore.exceptions import ClientError
import time

# ===============================================================
#  S3 CLIENT (LIARA BUCKET)
# ===============================================================

s3 = boto3.client(
    "s3",
    endpoint_url="https://storage.c2.liara.space",
    aws_access_key_id="lpbc1gfr7orr8fl6",     # ADD YOUR ACCESS KEY
    aws_secret_access_key="70227b7c-eb32-4f98-bf9e-4439b13d6c10", # ADD YOUR SECRET KEY
)

BUCKET_NAME = "janyar"

# ===============================================================
#  TEST BUCKET CONNECTION
# ===============================================================

def test_bucket_connection():
    """
    Tests S3 bucket connection by:
    1. Creating a test folder (prefix)
    2. Uploading a test file to that folder
    3. Listing the folder contents
    4. Cleaning up the test file
    """
    
    print("\n" + "=" * 70)
    print("  S3 BUCKET CONNECTION TEST")
    print("=" * 70)
    print(f"🔗 Endpoint: https://storage.c2.liara.space")
    print(f"🪣 Bucket: {BUCKET_NAME}")
    print("=" * 70 + "\n")
    
    test_folder = "test-folder/"
    test_file = f"{test_folder}test-file-{int(time.time())}.txt"
    test_content = f"Test file created at {time.strftime('%Y-%m-%d %H:%M:%S')}"
    
    try:
        # Step 1: Check if bucket exists
        print("📡 Step 1: Checking bucket access...")
        s3.head_bucket(Bucket=BUCKET_NAME)
        print("✅ Bucket exists and is accessible!\n")
        
        # Step 2: Create a test file in a test folder
        print(f"📤 Step 2: Creating test file in '{test_folder}'...")
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=test_file,
            Body=test_content.encode('utf-8'),
            ContentType='text/plain'
        )
        print(f"✅ Successfully created: {test_file}\n")
        
        # Step 3: List objects in the test folder
        print(f"📋 Step 3: Listing contents of '{test_folder}'...")
        response = s3.list_objects_v2(
            Bucket=BUCKET_NAME,
            Prefix=test_folder
        )
        
        if 'Contents' in response:
            print(f"✅ Found {len(response['Contents'])} object(s):")
            for obj in response['Contents']:
                size_kb = obj['Size'] / 1024
                print(f"   • {obj['Key']} ({size_kb:.2f} KB)")
        else:
            print("⚠️  No objects found in test folder")
        print()
        
        # Step 4: Read the test file back
        print("📥 Step 4: Reading test file content...")
        obj = s3.get_object(Bucket=BUCKET_NAME, Key=test_file)
        content = obj['Body'].read().decode('utf-8')
        print(f"✅ File content: {content}\n")
        
        # Step 5: Clean up test file
        print("🧹 Step 5: Cleaning up test file...")
        s3.delete_object(Bucket=BUCKET_NAME, Key=test_file)
        print(f"✅ Deleted: {test_file}\n")
        
        # Final success message
        print("=" * 70)
        print("🎉 SUCCESS! Your S3 bucket connection is working perfectly!")
        print("=" * 70)
        print("✓ Bucket accessible")
        print("✓ Can create folders/files")
        print("✓ Can list objects")
        print("✓ Can read files")
        print("✓ Can delete files")
        print("=" * 70 + "\n")
        
        return True
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        
        print("\n" + "=" * 70)
        print("❌ CONNECTION FAILED!")
        print("=" * 70)
        print(f"Error Code: {error_code}")
        print(f"Error Message: {error_message}")
        print("=" * 70)
        
        if error_code == '403':
            print("\n💡 Possible solutions:")
            print("   • Check your access key ID")
            print("   • Check your secret access key")
            print("   • Verify bucket permissions")
        elif error_code == '404':
            print("\n💡 Possible solutions:")
            print("   • Check bucket name spelling")
            print("   • Verify bucket exists in Liara")
        else:
            print("\n💡 Check your credentials and endpoint URL")
        
        print("=" * 70 + "\n")
        return False
        
    except Exception as e:
        print("\n" + "=" * 70)
        print("❌ UNEXPECTED ERROR!")
        print("=" * 70)
        print(f"Error: {str(e)}")
        print("=" * 70 + "\n")
        return False


# ===============================================================
#  MAIN EXECUTION
# ===============================================================

if __name__ == "__main__":
    success = test_bucket_connection()
    
    if success:
        print("✅ You can now safely use this S3 connection in your main script!")
    else:
        print("⚠️  Please fix the connection issues before proceeding.")